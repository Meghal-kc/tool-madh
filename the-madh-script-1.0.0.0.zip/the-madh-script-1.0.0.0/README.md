# the-madh-script
Developed by Meghal Kc
bascically this script is a modification of msf venepenetration tool
modes:
1.hacker_mode*
2.simple_mode
3.parental_mode*
@installing hacker_mod:
apt update
sudo su
hacker_mode/madh.
run.exe/modheacker
hacker.runtorun.exe
start.achp
[IT WILL RUN AFTER THIS STEP][IT WILL RUN AFTER THIS STEP]
NOTE:TO INSTALL ALL THE TOOLS U MUST KNOW MY PASSCODE****
@installing simple_mode:
apt update
sudo su
simple_mode/madh.
run.exe/modesimple
simple.runtorun.exe
start.achp
[IT WILL RUN AFTER THIS STEP][IT WILL RUN AFTER THIS STEP]
NOTE:TO INSTALL ALL THE TOOLS U MUST KNOW MY PASSCODE****
@installing parental_mode:
apt update
sudo su
parental.install.payload./run
payload/runtorun.sh
parental.apk
install.sh
[after creating payload using msfscriptmadh passcode creation page will apear.]
after creating pass
select your kids phone/tab/pc/wificonected_devices
if it is phone : phone.madh.sh
if it is tab : tab.madh.sh
if it is pc : pc.madh.sh
if it is wificonected_devices :wifi{devicename in wifi}.sh
it will run....

*use this script with msfvenepenetration tool*
*to use this script you want to know my passcode*
       .....use it wisely.....
use this tool for good purposes.
use sudo su with all comands
commands work in kali mod 1.6.889.0
this is the madh script!!!!!!!
if u want this script pls contact me via: gmail
gmail:meghalkcabc@gmail.com
